# messageboard
jdbc+jsp+servlet+mysql 留言板项目

开发工具：Eclipse IDE Enterprise Java Developers
  数据库：MySQL 5.7.27
  服务器：Tomcat 7.0
  数据库管理软件：MySQL WorkBench
  
  
